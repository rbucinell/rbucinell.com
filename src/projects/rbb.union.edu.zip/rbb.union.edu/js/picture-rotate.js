//DAD, just update to the new number of the highest PIC##.jpg
var number_of_pictures = 50;
var SECONDS = 3;
var badfiles = [];
var goodfiles = [];
var cur = 1;
var image;
var $portrait = {};

function rotatePictures()
{
	if( badfiles.indexOf(cur) >= 0 )
	{
		cur++;
		rotatePictures();
	}
	else
	{
		if(  cur == number_of_pictures )
		{
			cur = 1;
			number_of_pictures = goodfiles.length;
		}

		image = new Image();
		image.width = 225;
		image.height = 225;
		image.onload = changePix;
		image.onerror = skipPix;
		image.src = "img/rotation/PIC" + ((cur < 10 ) ? "0" + cur : cur) + ".jpg";
	}
}

function changePix()
{	
	goodfiles.push(cur);
    $portrait.css('background-image', 'url(' + image.src + ')');
	cur++;
	setTimeout(rotatePictures, (SECONDS * 1000) );
}

function skipPix(){
	badfiles.push( cur++ );
	rotatePictures();
}

$(function(){
	badfiles = [];
	$portrait = $("#profile > div.portrate");
	$portrait.css("all ease 3s");
    setTimeout(rotatePictures, (SECONDS * 1000) );
});