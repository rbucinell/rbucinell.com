/////////////////////////////////////
/////////// MP3 Renamer /////////////
///// Author: Ryan Bucinell//////////
/////version: 1.0.0 - 7/9/2009 //////
/////////////////////////////////////

//////////
///Usage//
//////////
java -jar MP3Renamer.jar rootPath

where rootPath: is the root folder you want to modify; optional, but if null
		user will be prompted for path.

/////////////////
///Description///
/////////////////

This program will re-write all the mp3 files in your selected folder (and sub folders)
to "Artist - Title".This is only the v1.0. And I was really pissed at iPod for renaming
files to random character combos (i.e. XANW.mp3), so I started to develop this progam
Currently files are just renamed; no creation of folders of artists/albums

///////////////////////
//////Known Issues/////
///////////////////////
- if there is a problem, this will skip the file
- does not re-organize based on artist/album info
- only formats mp3 (looking to modify all ID3 tag files)

////////////////////////
/////////Thanks/////////
////////////////////////
Thanks to Eric Farng for the ID3 Library!