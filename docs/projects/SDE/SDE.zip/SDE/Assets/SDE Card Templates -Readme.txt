First off, let me just say thank you for using my templates!

I hope to see a whole slew of custom cards come from sharing these template files. If you didn't get this file from BoardgameGeek.Com, please check out the section there for Variants on the forum and the Files section to make sure you have the most recent version of the templates.

The .PSD files have information on how to use the templates within them, please use the Note tool (under the Eyedropper tool) to read the extensive notes. If you get stuck, feel free to post in the forums or message me directly on BGG.

Happy customizing,

-Bioautomaton

Fonts needed are:
Albertus MT
Adelon Bold
Arial
