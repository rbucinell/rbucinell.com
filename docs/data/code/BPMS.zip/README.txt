_______________  ___ _____ 
| ___ \ ___ \  \/  |/  ___|
| |_/ / |_/ / .  . |\ `--. 
| ___ \  __/| |\/| | `--. \
| |_/ / |   | |  | |/\__/ /
\____/\_|   \_|  |_/\____/    
////////////////////////////////////////////
//////Beer Pong Management System //////////
////////////////////////////////////////////
Title: Beer Pong Management System (BPMS or PMS)
Version: 1.7.1.0
Release: 6/17/09
Author: Ryan Bucinell
Developer: SwiftStriker Productions

-------------------
Table of Contents
-------------------
I. 	Please Note
II.	Description
III.	System Requirements
IV.	Save System
V.	Updates
VI.	Known Issues
VII.	Legal
-------------------
Please Note
-------------------
This is a work in progress, and a personal project motivated only by my boredom.
So this project has been picked up and forgotten so i may have had different game
plans. Naturally introducing bugs, because otherwise like all programers, my code
is flawless (lol). Please leave me feeback at SwiftStriker00@Gmail.com if you have
anything

-------------------
Descritption:
-------------------

 This is a management system for your beer pong table. I've noticed
at large parties that everyone putting their keys on the table, leads
to people re-arrange the line, people loosing keys, the subsequent 
"whos keys are these" game. So this program gives the host the 
ability to maintain the line, longest streak, and modify
settings, and be able to password protect it while doing so. With further
development more features to saving and modifying teams will be added
along with more stats.

-------------------
System Requirements:
-------------------
1) Windows XP or more Recent
2) .Net Framework 3.5 (Vista and Win7 users should have this
   by Windows updates. Download from link below:

http://www.microsoft.com/downloads/details.aspx?FamilyId=333325FD-AE52-4E35-B531-508D977D32A6&displaylang=en

3) 700K space on disk (lol god i hope you do)
5) 15,500k availbe RAM

-------------------
Save System
-------------------

  The save system is fairly simple, but is not the normal file load/save so I will 
take some time to explain it here. As advertised this is a standalone exe, and it 
will work fine without any installation or other files (except .Net). During the 
first time you run the program, you can create a bunch of teams. If you want to 
save them you must go to File > Save & Exit. The red [x] button will not do it.
The default save goes to your My Documents folder. Now when you run the program again
by just clicking on it, it will look for and load the save file in you My Documents 
folder. However if you take another XML file (properly formated of course) and drag
it ontop of the exe, it will load from and save to that file. You can do this multiple
times, so if you are running two parties you can run two copies of this program at the
same time and not mix the lines. For example:

[table1.xml]-----dragged onto ----> [BPMS.exe]---> Program starts and its file is table1.xml

[table2.xml]-----dragged onto ----> [BPMS.exe]---> Program starts and its file is table2.xml

doubleclick ---->[BPMS.exe]---> Program starts and its file is "My Documents\BPMS_save.xml"

3 tables are now running!


I've stress tested the program up to 60,000 teams. the only thing that lags is the creation of the list
in the Team List form, otherwise all functional and responsive

-------------------
Updates
-------------------
v1.7	- About page error fixed; Prompt on exit for save feature added
	- Refactorization of teams in code, cleaned up unnecessary code

v1.6	- About popup added. Stress tested to 50,000 teams, still functional
	- Added Total records to teams

v1.5	- Themes Menu and Help menu both added and functional.

v1.4	- Added ListTeams Form! Many features placed in

v1.3	- Encryption of admin password in save file && Minor Bug 
	  fixes regarding loading xml

v1.2b	- Save System implemented, default and passed saves

v1.1	- Menu Items implemented

v1.0	- Minor Bug fixes, updated warning messeges, and fixed 
	  display for record game

v0.9	- Password Proection Implemented

v0.8	- can now remove in middle of queue

v0.7.1 	- Added pictures to fields and icon to Context

v0.7 	- Menus Designed, Queue now visible

v0.6 	- Ability to requeue previous teams implemented

v0.5 	- Basic Functionallity of line, and queuing 


-------------------
Known Issues
-------------------

	1) Backup of the current players and the line not saved
		-Planned for next itteration

	[FIXED for 1.7] 2) No Save Prompt on [x] button on control box


-------------------
Legal
-------------------
This program is free to use, distribute, and download. It is
closed source to protect the intulectual property, but if
you are curious on any of the implementation, I will be more
than willing to expalin the basics.
This program at the moment is a stand alone .exe that does not
use system I/O past the saving the XML. This means that there 
is no threat of virus or whatever, but by downloading this 
program you accept the fact that you are giving me access to your 
file system, and in the event I do create functionality, I have the
 ability to do what I want. I can only garentee the above if you 
recieve a release directly from me or my website, and other distributor 
could modify the program. You are responsible for your computer,
regardless of downloading and using this product. Enjoy.

